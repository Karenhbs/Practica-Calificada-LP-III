package PracticaCalificada;

public class Piano implements InstrumentoMusical {
	@Override
	public void tocar() {
		System.out.println("El piano está siendo tocado.");
    }

    @Override
    public void afinar() {
        System.out.println("El piano está siendo afinado.");
    }
}