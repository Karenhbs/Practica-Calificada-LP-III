package PracticaCalificada;

public class CuentaBancaria{
	private double saldo;
	public CuentaBancaria(double saldoInicial) {
		this.saldo=saldoInicial;
	}
	
	public void retirar(double monto) throws Exception{
		if (monto > saldo) {
			throw new Exception("Saldo insufuciente");		
		} if (monto<0) {
			throw new Exception("No se puede retirar, monto negativo");
		}else {
			saldo-=monto;
			System.out.println("Operación exitosa. Su saldo es: "+ saldo);
		}
	}
}