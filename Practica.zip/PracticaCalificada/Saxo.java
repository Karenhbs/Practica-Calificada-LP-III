package PracticaCalificada;

public class Saxo implements InstrumentoMusical {
	@Override
	public void tocar() {
		System.out.println("El saxo está siendo tocado.");
    }

    @Override
    public void afinar() {
        System.out.println("El saxo está siendo afinado.");
    }
}
