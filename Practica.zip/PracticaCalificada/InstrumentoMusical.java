package PracticaCalificada;

public interface InstrumentoMusical {
	void tocar();
	void afinar();
}
