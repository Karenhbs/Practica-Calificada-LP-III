package PracticaCalificada;

public interface Imprimible {
    void imprimir();
}
