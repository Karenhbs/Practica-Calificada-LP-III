package TestMain;

import PracticaCalificada.InstrumentoMusical;
import PracticaCalificada.Piano;
import PracticaCalificada.Saxo;

public class MainMusical {
 public static void main(String[] args) {
     InstrumentoMusical[] instrumentos = new InstrumentoMusical[2];
     instrumentos[0] = new Piano();
     instrumentos[1] = new Saxo();

     for (InstrumentoMusical instrumento : instrumentos) {
         instrumento.tocar();
         instrumento.afinar(); 
         System.out.println();
     }
 }
}

