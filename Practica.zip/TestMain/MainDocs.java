package TestMain;

import PracticaCalificada.Imprimible;
import PracticaCalificada.Documento;
import PracticaCalificada.Imagen;

public class MainDocs {
    public static void main(String[] args) {
        Imprimible doc = new Documento();
        Imprimible img = new Imagen();

        doc.imprimir(); 
        System.out.println();
        img.imprimir(); 
    }
}
