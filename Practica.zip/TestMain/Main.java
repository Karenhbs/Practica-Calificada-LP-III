package TestMain;

import Practica4_1.Circulo;
import Practica4_1.Figura;
import Practica4_1.Rectangulo;
import Practica4_1.Triangulo;
import Practica4_1.CalculadorDeArea;

public class Main {
    public static void main(String[] args) {
        CalculadorDeArea calculador = new CalculadorDeArea();

        Figura rectangulo = new Rectangulo(5, 10);
        Figura circulo = new Circulo(7);
        Figura triangulo = new Triangulo(3, 6);

        System.out.println("Área del rectángulo: " + calculador.calcular(rectangulo));
        System.out.println("Área del círculo: " + calculador.calcular(circulo));
        System.out.println("Área del triángulo: " + calculador.calcular(triangulo));
    }
}