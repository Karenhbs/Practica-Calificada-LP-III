package TestMain;

import java.util.Scanner;

import PracticaCalificada.CuentaBancaria;

public class MainCuenta{
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        try {
            System.out.print("Ingrese el saldo inicial de su cuenta bancaria: ");
            double saldoInicial = scanner.nextDouble();
            CuentaBancaria cuenta = new CuentaBancaria(saldoInicial);
            if (saldoInicial < 0) {
                throw new Exception("El saldo inicial debe ser un número positivo.");
            }
            
            System.out.print("Ingrese el monto a retirar: ");
            double montoARetirar = scanner.nextDouble();

            cuenta.retirar(montoARetirar);

        } catch (NumberFormatException e) {
            System.out.println("Error: Por favor ingrese un número positivo.");
        } catch (Exception e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            scanner.close(); 
        }
    }
}


